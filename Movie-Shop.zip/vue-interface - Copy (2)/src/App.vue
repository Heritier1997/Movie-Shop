<template>
  
  <div id="app">

    <div class="bg-dark" style="">
      <navigation/>
      <router-view
      :movies="searchResponse" :checklist="checklist" 
      @searchItem="searchItem"></router-view>
    </div>

  </div>

</template>
<script >

// import axios from "axios";
// import _ from 'lodash';
import Navigation from "./components/Nav.vue";

export default {

  name: 'app',
  data() {
    return {
      movies: [{
          id: 1,
          name: 'Parasite',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1579120722/amc-cdn/production/2/movies/60500/60540/Poster/p_800x1200_AMC_Parasite2019_En_122519.jpg',
          price: '4.55',
        },
        {
          id: 2,
          name: 'Birds of Prey',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1576256007/amc-cdn/production/2/movies/54400/54416/PosterDynamic/97309.jpg',
          price: '3.75',
        },
        {
          id: 3,
          name: 'Bad Boys',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1570033494/amc-cdn/production/2/movies/49000/48961/PosterDynamic/93215.jpg',
          price: '7.00',
        },
        {
          id: 4,
          name: 'Dolittle',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1571067779/amc-cdn/production/2/movies/53500/53488/PosterDynamic/93846.jpg',
          price: '3.50',
        },
        {
          id: 5,
          name: 'Jumanji',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1572534347/amc-cdn/production/2/movies/57600/57550/PosterDynamic/94562.jpg',
          price: '6.40',
        },
        {
          id: 6,
          name: 'Gretel And Hansel',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1576176698/amc-cdn/production/2/movies/60100/60109/PosterDynamic/97243.jpg',
          price: '2.30',
        },
        {
          id: 7,
          name: 'Little Women',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1574279085/amc-cdn/production/2/movies/57700/57706/PosterDynamic/96511.jpg',
          price: '3.55',
        },
        {
          id: 8,
          name: 'The Rhythm Section',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1569546464/amc-cdn/production/2/movies/55400/55423/PosterDynamic/92048.jpg',
          price: '4.10',
        },
        {
          id: 9,
          name: 'Knives Out',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1579120615/amc-cdn/production/2/movies/59200/59161/Poster/p_800x1200_AMC_KnivesOut_121719.jpg',
          price: '2.25',
        },
        {
          id: 10,
          name: 'The Rise of Skywalker',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1571709576/amc-cdn/production/2/movies/53700/53726/PosterDynamic/94205.jpg',
          price: '2.75',
        },
        {
          id: 11,
          name: 'The Assistant',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1576187211/amc-cdn/production/2/movies/62100/62089/PosterDynamic/97248.jpg',
          price: '3.65',
        },
        {
          id: 12,
          name: 'Porgy and Bess',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1563394732/amc-cdn/production/2/movies/61000/60959/PosterDynamic/86335.jpg',
          price: '1.55',
        },
        {
          id: 13,
          name: 'The Turning',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1570638992/amc-cdn/production/2/movies/57100/57118/PosterDynamic/93385.jpg',
          price: '7.99',
        },
        {
          id: 14,
          name: 'Just Mercy',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1576168113/amc-cdn/production/2/movies/55700/55682/PosterDynamic/97239.jpg',
          price: '4.35',
        },
        {
          id: 15,
          name: 'Spies in Disguise',
          src: 'https://amc-theatres-res.cloudinary.com/image/upload/f_auto,fl_lossy,h_465,q_auto,w_310/v1569599513/amc-cdn/production/2/movies/51300/51299/PosterDynamic/92058.jpg',
          price: '3.99',
        }
      ],
      checklist: [],
      searchWord:''
    }
  },
  components: {
    Navigation
  },
  computed: {
    searchResponse() {
      return this.movies.filter(item => {
        return (
          item.name.toLowerCase().match(this.searchWord.toLowerCase()) ||
          item.price.toLowerCase().match(this.searchWord.toLowerCase())
        );
      });
    }
  },
  methods:{
    searchItem(value){
      this.searchWord = value;
    }
  }
} 
</script>
