import Vue from 'vue';
import App from './App.vue';
import VueRouter from 'vue-router';

import "bootstrap";
import "bootstrap/dist/css/bootstrap.css";
import {library} from '@fortawesome/fontawesome-svg-core';

import {
  faPlus, faMinus, faTrash, faCheck,faShoppingCart
}from "@fortawesome/free-solid-svg-icons";

library.add(faPlus, faMinus, faTrash, faCheck,faShoppingCart);
Vue.use(VueRouter);
Vue.config.productionTip = false

import Items from './components/Items.vue';
import CheckList from './components/CheckList.vue';

const router = new VueRouter({
  routes:[
    {
      path: "*",
      component: Items 
    },
    {
      path: "/checkins",
      component: CheckList 
    }
  ]
});

new Vue({
  render: h => h(App),
  router
}).$mount('#app')
