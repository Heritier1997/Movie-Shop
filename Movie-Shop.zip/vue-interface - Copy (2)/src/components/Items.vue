<template>
    
    <div class="container px-5 bg-dark">
        <!-- cart -->
        <div class="d-flex justify-content-end sticky-top" v-if="cart>0">
                <div class="btn-group my-2 bg-dark">
                    <a class="btn dropdown-toggle text-light px-5" 
                    data-toggle="dropdown" href="#">
                        
                        <font-awesome-icon icon="shopping-cart"></font-awesome-icon>
                        Cart
                        <span class="badge rounded-circle bg-warning px-2 text-dark">
                            {{cart}}
                        </span>
                    </a>
                    <ul class="dropdown-menu px-2" style="width:250px;" @click.stop>
                        <!-- dropdown menu links -->
                        <li v-for="(x,key) in checklist" :key="key">
                            <div class=""  v-if="x.qty>0">
                                <font-awesome-icon icon="plus"
                                @click="addQuantity(key)" 
                                class="text-success mx-2"></font-awesome-icon>
                                <font-awesome-icon icon="minus" 
                                @click="reduceQuantity(key)"
                                class="text-danger mx-2"></font-awesome-icon>
                                <span class="badge rounded-circle bg-warning">{{x.qty}}</span>
                                {{x.name}}
                                <span class="text-warning font-weight-bold">${{x.total}}</span>
                            </div>
                        </li>
                        <hr>
                        <div class="text-right pr-4">
                            <a href="#/checkins" class="font-weight-bold btn btn-outline-success"
                            >total: ${{total}}</a>
                        </div>
                    </ul>
                </div>
        </div>
        <div class="container">
            <div class="my-2 d-flex justify-content-center px-5 py-4">
                <input class="form-control text-center" type="text"
                placeholder="Search a movie or a price" v-model="searchMovie"/>
            </div>

        <div class="py-1 row d-flex justify-content-center">
                <div class="col-lg-4 mt-3" v-for="(x,key) in movies" :key="key">

                    <div class="card">
                        <h4 class="text-center">{{x.name}}</h4>
                        <div class="card-body bg-light border-0 py-0 d-flex 
                        justify-content-center text-center">
                            <img :src="x.src"
                            class="img-fluid" width="300" height="200"/>
                        </div>
                        <div class="card-footer bg-light py-2 text-center">
                            <button class="btn btn-warning px-3 mb-2"
                            @click.prevent="myFunction(key)">
                            <font-awesome-icon icon="plus"></font-awesome-icon>
                                Buy ${{x.price}}
                            </button><br>
                        </div>
                    </div>  
                </div>
            </div>  
        </div>
    </div>

</template>

<script>
import {FontAwesomeIcon} from '@fortawesome/vue-fontawesome';
// import _ from 'lodash';

export default {
    data(){
        return{
            searchMovie:'',
            key:0
        }
    },
    components:{
        FontAwesomeIcon
    },
    props:['checklist','movies'],
    computed:{
        cart() {
            return this.checklist.length;
        },
        total(){
            var a = 0
            this.checklist.forEach(element => {
                a+= Number(element.total);
            });
            return a;
        },
        totalOfSameItem(){
            return 0
        }
    },
    methods:{
        addItem(key){
            var obj = {
                id:key,
                name: this.movies[key].name,
                src: this.movies[key].src,
                price:  this.movies[key].price,
                qty:1,
                total:(this.movies[key].price)
            }
            this.checklist.push(obj);            
        },
        checkAdult(age) {
           return age.id === this.key;
        },
        myFunction(key) {
            this.key = key;
            var a = this.checklist.findIndex(this.checkAdult);
            if (a===-1){
                this.addItem(key);
            }else{
                this.checklist[a].qty++;
                this.getRealValue(a);
            }
        },
        getRealValue(key){
            var x = this.checklist[key].qty;
            var y = this.checklist[key].price;
            this.checklist[key].total = (x*y).toFixed(2);
        },
        addQuantity(key){
            this.checklist[key].qty++;
            this.getRealValue(key);
        },
        reduceQuantity(key){
            this.checklist[key].qty--;
            var x = this.checklist[key].qty;
            if (x<=0){
                this.checklist[key].qty = 0;
            }
            this.getRealValue(key);
        }
    },
    watch:{
        searchMovie(){
            this.$emit("searchItem", this.searchMovie);
        }
    }
    
}
</script>