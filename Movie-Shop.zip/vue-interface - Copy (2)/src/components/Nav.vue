<template>
    <div class="container-fluid px-0">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" 
        data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" 
        aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <!-- Name of the app -->
            <a class="navbar-brand" href="#/">
                <span class="h1 text-warning px-1">Movie-Shop</span>
            </a>
            <!-- end Name of the app -->

            <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            
            </ul>
            
        </div>
    </nav>

    </div>
</template>

<script>
export default {

}
</script>