<template>
    
    <div class="container-fluid bg-dark my-0 my-3">
        <div class="container bg-dark">
            <h1 class="text-center text-white display-3">Movies Added</h1>
            <div class="text-right mb-2">
                <a class="btn btn-info mr-2" href="#/">Continue Shopping</a>
            </div>
            
            <table class="table text-white" v-if="checklist.length>0">
                <tr>
                    <th>#</th>
                    <th>Image</th>
                    <th>Item</th>
                    <th>Quantity</th>
                    <th>Price</th>
                </tr>

                <tr v-for="(x,key) in checklist" :key="key">
                    
                        <td v-if="x.qty>0">{{key+1}}</td>
                        <td v-if="x.qty>0">
                            <img :src="x.src"
                                class="img-fluid" width="50"/>
                        </td>
                        <td v-if="x.qty>0"><h3>{{x.name}}</h3></td>
                        <td v-if="x.qty>0"><h3>{{x.qty}}</h3></td>
                        <td v-if="x.qty>0"><h3>${{x.total}}</h3></td>
                </tr>

                <tr>
                    <td colspan="4" class="text-warning text-center">
                        <h3>Total</h3>
                    </td>
                    <td colspan="1" class="text-warning text-rights">
                        <h3>${{total}}</h3>
                    </td>
                </tr>
            </table>
        </div>
    </div>

</template>

<script>
export default {

    props:['checklist'],
    computed:{
        total(){
            var a = 0
            this.checklist.forEach(element => {
                a+= Number(element.total);
            });
            return a;
        }
    }
}
</script>